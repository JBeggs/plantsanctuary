from django.contrib import admin

from payment.models import Payment


admin.site.register(Payment)
